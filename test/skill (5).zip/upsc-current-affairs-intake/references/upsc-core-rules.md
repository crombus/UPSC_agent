# UPSC Core Rules

Use these rules in every UPSC output.

## Syllabus boundaries
Cover only UPSC CSE relevant areas unless the user explicitly asks otherwise: Prelims GS Paper I, Prelims CSAT Paper II, Essay, GS I, GS II, GS III, GS IV, Philosophy Optional Paper I and II only when explicitly requested, and Interview/Personality Test.

## Source discipline
Never fabricate current affairs, committees, reports, rankings, schemes, laws, judgments, statistics, dates, or institutions. Separate:

- FACT: source-backed statement.
- INFERENCE: reasoning derived from facts.
- UPSC SYNTHESIS: exam-oriented framing, traps, static linkage, mains dimensions, or interview angle.

Source priority: official UPSC syllabus, PIB, ministries/departments, Parliament/PRS, RBI/SEBI/statutory bodies, courts, Budget/Economic Survey/government datasets, international organisations, reputed newspapers, coaching sources only for framing.

If source verification is unavailable and the user has not uploaded material, do not generate fresh current affairs. Ask for notes/PDFs or clearly state that source-safe current affairs cannot be produced.

## Date-window rules
Use Asia/Kolkata. Weekly mode always runs Sunday to Saturday.

- "this week": the Sunday-to-Saturday week containing today.
- "last week": the immediately previous Sunday-to-Saturday week.
- "latest completed week": the most recent fully completed Sunday-to-Saturday week.
- Saturday weekly run: use the current Sunday-to-Saturday week unless the user says completed/latest completed/last week.
- Monthly/yearly mode: use the exact date range if provided; otherwise state the inferred range.

Always show exact dates used.

## Default weekly bundle
Unless the user specifies otherwise:

- Prelims GS1: 50 MCQs.
- Prelims CSAT: 20 MCQs.
- Mains: 10 questions.
- Interview: 8 questions.
- Revision notebook: create as a separate notebook-style PDF.

## UPSC marking and time
Prelims GS1 marking:

- Correct: +2.00.
- Incorrect: -0.33.
- Not attempted/skipped/blank: 0.
- Actual UPSC reference: 100 MCQs in 120 minutes.
- Scaled time = number of GS1 questions * 1.2 minutes.

Prelims CSAT marking:

- Correct: +2.50.
- Incorrect: -0.83.
- Not attempted/skipped/blank: 0.
- Actual UPSC reference: 80 MCQs in 120 minutes.
- Scaled time = number of CSAT questions * 1.5 minutes.

Show suggested attempt time in every question paper PDF.

## PDF bundle outputs
For a full revision bundle, create five separate PDFs:

1. Prelims GS1 Question Paper PDF.
2. Prelims CSAT Question Paper PDF.
3. Mains + Interview Question Paper PDF.
4. Answer Key + Explanations PDF for GS1, CSAT, Mains frameworks, and Interview guidance.
5. Revision Notebook PDF.

Question-paper PDFs must contain no answers, hints, explanations, answer keys, memory hooks, or source notes that reveal answers.
