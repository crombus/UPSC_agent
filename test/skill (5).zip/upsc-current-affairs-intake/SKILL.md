---
name: upsc-current-affairs-intake
description: create source-verified upsc current-affairs issue inventories for daily, weekly, monthly, multi-month, yearly, and custom date ranges. use when the user provides pdfs, notes, current-affairs text, topics, or only a date range and needs upsc-relevant issues, source transparency, fact/inference/synthesis separation, recommended study order, topic priority, or a source-safe input base for revision notebooks and test-paper pdfs.
---

# UPSC Current Affairs Intake

Load `references/upsc-core-rules.md` before producing a date-window current-affairs set.

## Intake workflow

1. Identify inputs: PDFs, notes, existing MCQs, topic list, date range, or mixed sources.
2. Resolve date window using Asia/Kolkata. Weekly means Sunday to Saturday.
3. Verify current-affairs facts from reliable sources when source access is available.
4. If source access is not available and the user did not upload material, do not invent fresh current affairs.
5. Extract UPSC-relevant issues only; ignore trivial news.
6. Deduplicate repeated issues and merge overlapping ones.
7. Map each issue to Prelims GS1, GS I/II/III/IV, Essay, Interview, and CSAT only if explicitly useful.
8. Assign priority: High / Medium / Low.
9. Assign depth: Basic / Standard / Deep.
10. Return a clean topic inventory for downstream notebook and test-paper generation.

## Source transparency block

Always start date-range current-affairs output with:

```text
## Source Transparency
Date range used:
Weekly boundary, if applicable: Sunday to Saturday
Source base: uploaded material / verified web sources / mixed / unavailable
Sources used:
Unavailable sources:
Verification confidence:
Source disagreement detected: Yes / No
```

## Issue format

Use this structure for each issue:

```text
## Issue: <name>
Theme:
Priority:
Suggested depth:
UPSC mapping:

FACTS:
- FACT: <source-backed statement>. Source: <source>. Confidence: High/Medium/Low.

INFERENCE:
- INFERENCE: <clearly labelled analysis>.

UPSC SYNTHESIS:
- Static linkage:
- Prelims trap:
- Mains angle:
- Interview angle:
```

## Recommended study order

After the issue list, provide a study order table with topic, priority, depth, and why this order. Do not start teaching automatically unless the user asks.

## Output for other skills

When another skill needs structured input, produce:

- Topic title.
- Source anchor.
- Subject/theme.
- Prelims relevance.
- Mains relevance.
- Interview relevance.
- Static linkage.
- Current-affairs anchor.
- Priority.
- Suggested depth.
