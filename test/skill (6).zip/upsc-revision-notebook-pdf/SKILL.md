---
name: upsc-revision-notebook-pdf
description: create notebook-style upsc revision pdfs for daily, weekly, monthly, multi-month, yearly, or custom study scopes. use when the user asks for a revision notebook, workbook, notes pdf, one-page revision sheets, saturday weekly revision, source-backed current-affairs notes, active recall pages, prelims traps, mains dimensions, interview angles, or a printable revision pdf separate from test papers and answer keys.
---

# UPSC Revision Notebook PDF

Load `references/upsc-core-rules.md` and `references/revision-notebook-template.md` before creating the notebook. Follow the environment's PDF creation instructions and produce a downloadable PDF.

## Purpose

Create a revision notebook that the user can read before attempting the separate Prelims GS1 paper, CSAT paper, and Mains+Interview paper. This PDF is for revision, not testing.

## Required file

`UPSC_Revision_Notebook_<date-range-or-scope>.pdf`

## Notebook rules

- Keep it printable, clean, and revision-friendly.
- Use A4, page numbers, clear headings, and enough whitespace.
- Include source transparency, but do not overload pages with long URLs.
- Separate FACT, INFERENCE, and UPSC SYNTHESIS.
- Use uploaded PDFs/notes as the main source when provided.
- For weekly mode, show the exact Sunday-to-Saturday range.
- For monthly/multi-month/yearly mode, divide content by week/theme if long.

## Notebook workflow

1. Confirm or infer scope and date range.
2. Build a topic inventory from uploaded materials and/or verified current affairs.
3. Group by theme: Polity, Economy, Environment, S&T, IR, Security, Social Justice, Reports/Indices, Schemes, Culture, Geography, Ethics.
4. Create topic capsules.
5. Add active recall and self-testing boxes.
6. Add Prelims traps, Mains dimensions, Interview angles, and memory hooks.
7. Add weekly/monthly/yearly revision planner pages.
8. Export as a PDF.

## Do not include

- Full MCQ answer key from the test paper.
- Long model answers.
- Unsupported current-affairs claims.
- Random trivia outside UPSC relevance.
