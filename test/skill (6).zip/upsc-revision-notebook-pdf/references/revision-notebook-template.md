# Revision Notebook Template

Use this structure for `UPSC_Revision_Notebook_<scope>.pdf`.

## Cover page
- Title.
- Date range/scope.
- Weekly boundary if applicable: Sunday to Saturday.
- Source base: uploaded PDFs/notes, verified sources, or mixed.
- How to use this notebook.

## Table of contents
Group by theme and topic.

## Source transparency
- Date range used.
- Source base.
- Verification confidence.
- Source disagreement, if any.

## Theme index
For each theme, list topics and priority.

## Topic capsule format
For each topic:

1. Topic title.
2. UPSC mapping: Prelims GS1 / GS I / GS II / GS III / GS IV / Essay / Interview.
3. Why in news or why relevant.
4. FACTS: source-backed points only.
5. Static linkage.
6. Prelims traps.
7. Mains dimensions.
8. Interview angle.
9. Data/report/judgment/scheme anchors, if verified.
10. Memory hook.
11. Active recall box: 3-5 questions without answers.
12. Mistake-risk box: what aspirants confuse.
13. Space for user notes.

## End sections
- Must-revise facts.
- Must-revise static concepts.
- Prelims traps list.
- Mains probable themes.
- Interview-sensitive issues.
- 7-day revision plan for weekly notebook, or segmented plan for monthly/yearly notebook.
- Blank reflection page: weak areas, reattempt plan, pending doubts.
