# Test Paper Output Specification

## PDF 1: Prelims GS1 Question Paper

Filename: `UPSC_Prelims_GS1_Question_Paper_<scope>.pdf`

Include:
- Cover page.
- Date range/scope.
- Total GS1 MCQs.
- Total marks = question count * 2.
- Marking: +2 correct, -0.33 incorrect, 0 unattempted.
- Suggested attempt time = question count * 1.2 minutes.
- Actual UPSC reference: 100 MCQs in 2 hours.
- Instructions.
- MCQs only.
- Blank answer grid.

Do not include answers, hints, source notes, explanations, or memory hooks.

## PDF 2: Prelims CSAT Question Paper

Filename: `UPSC_Prelims_CSAT_Question_Paper_<scope>.pdf`

Include:
- Cover page.
- Date range/scope.
- Total CSAT MCQs.
- Total marks = question count * 2.5.
- Marking: +2.5 correct, -0.83 incorrect, 0 unattempted.
- Suggested attempt time = question count * 1.5 minutes.
- Actual UPSC reference: 80 MCQs in 2 hours.
- Instructions.
- CSAT MCQs/passages/data sets only.
- Blank answer grid.

Question mix should include comprehension, logical reasoning, analytical ability, decision-making, problem-solving, basic numeracy, and data interpretation. Keep CSAT in a separate paper.

## PDF 3: Mains + Interview Question Paper

Filename: `UPSC_Mains_Interview_Question_Paper_<scope>.pdf`

Include:
- Cover page.
- Date range/scope.
- Instructions.
- Section A: Mains questions with GS paper mapping and word limit.
- Section B: Interview questions.

Do not include model answer hints or talking points.

## PDF 4: Answer Key + Explanations

Filename: `UPSC_Answer_Key_Explanations_<scope>.pdf`

Include:
- Cover page.
- GS1 answer key table.
- CSAT answer key table.
- Detailed GS1 explanations.
- Detailed CSAT solutions.
- Mains answer frameworks.
- Interview guidance.
- Revision diagnosis.
- Scoring instructions.

GS1 explanation format:
- Correct answer.
- Why correct.
- Why other options are wrong.
- Static linkage.
- Current-affairs anchor if verified.
- UPSC trap.
- Memory hook.

CSAT explanation format:
- Correct answer.
- Short solving method.
- Common wrong approach.
- Time-saving method.

Mains framework format:
- GS paper.
- Syllabus linkage.
- Demand of the question.
- Intro approach.
- Body dimensions.
- Current-affairs examples if verified.
- Way forward.
- Conclusion line.
- Common mistakes.

Interview guidance format:
- What the board may test.
- Balanced answer approach.
- Possible follow-up questions.
- Mistakes to avoid.
- 90-second answer structure.
