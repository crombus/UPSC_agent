---
name: upsc-test-paper-pdf
description: generate upsc exam-style pdf papers from uploaded notes, current-affairs pdfs, existing mcqs, topics, or date ranges. use when the user asks for prelims gs1 question paper pdf, separate csat question paper pdf, mains plus interview question paper pdf, answer key and explanations pdf, weekly/monthly/yearly test papers, saturday revision tests, marking rules, scaled attempt time, or strict no-answer question papers.
---

# UPSC Test Paper PDF

Load `references/upsc-core-rules.md` and `references/test-paper-output-spec.md` before generating PDFs. Follow the environment's PDF creation instructions and produce downloadable PDFs.

## Required outputs for full test bundle

Create four PDFs from this skill:

1. `UPSC_Prelims_GS1_Question_Paper_<date-range-or-scope>.pdf`
2. `UPSC_Prelims_CSAT_Question_Paper_<date-range-or-scope>.pdf`
3. `UPSC_Mains_Interview_Question_Paper_<date-range-or-scope>.pdf`
4. `UPSC_Answer_Key_Explanations_<date-range-or-scope>.pdf`

The revision notebook is created by the revision notebook skill as a fifth PDF when the user asks for the full bundle.

## Default counts

Unless the user specifies otherwise:

- Weekly: 50 GS1 MCQs, 20 CSAT MCQs, 10 Mains questions, 8 Interview questions.
- Monthly: 100 GS1 MCQs, 40 CSAT MCQs, 20 Mains questions, 15 Interview questions, unless too much for one PDF.
- Multi-month/yearly: split by month/quarter/theme before creating huge papers.

## Marking and time

Use exactly:

- GS1: +2.00 correct, -0.33 incorrect, 0 unattempted. Time = GS1 question count * 1.2 minutes.
- CSAT: +2.50 correct, -0.83 incorrect, 0 unattempted. Time = CSAT question count * 1.5 minutes.

Every question paper PDF must show total questions, total marks, negative marking, and suggested attempt time. Mention actual UPSC reference: GS1 has 100 MCQs in 2 hours; CSAT has 80 MCQs in 2 hours.

## Question-paper separation rules

- GS1 paper contains only Prelims GS1 MCQs.
- CSAT paper contains only CSAT MCQs.
- Mains+Interview paper contains only Mains questions and Interview questions.
- Answer PDF contains all answers and explanations.
- Question papers must not reveal answers, hints, explanations, memory hooks, source notes, or clue-like labels.

## Generation workflow

1. Resolve scope and date range.
2. Extract topic inventory from uploaded material, notes, MCQs, or verified current affairs.
3. Deduplicate and classify topics.
4. Build a blueprint for GS1, CSAT, Mains, and Interview.
5. Generate GS1 MCQs with UPSC-style traps and balanced answer distribution.
6. Generate CSAT MCQs separately: comprehension, reasoning, basic numeracy, decision-making, data interpretation, and analytical ability.
7. Generate Mains and Interview questions separately from MCQs.
8. Create the Answer Key + Explanations PDF with GS1 explanations, CSAT solutions, Mains frameworks, Interview guidance, and revision diagnosis.
9. Validate numbering across all papers.
10. Export PDFs.

## Quality checks before final delivery

- Each MCQ has one correct answer or an explicitly valid multi-statement key.
- No answer leakage in any question paper.
- GS1 and CSAT are separate PDFs.
- Mains+Interview is a separate PDF.
- One answer PDF covers all sections.
- Marking and time instructions are visible.
- Correct answer distribution is balanced.
- Question numbers in the answer PDF match the papers exactly.
