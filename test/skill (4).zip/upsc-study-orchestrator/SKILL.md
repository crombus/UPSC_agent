---
name: upsc-study-orchestrator
description: coordinate and route upsc study workflows across weekly, monthly, multi-month, yearly, and custom revision bundles. use when the user asks for upsc revision, saturday weekly runs, current-affairs date ranges, pdf bundles, separate prelims gs1/csat/mains-interview papers, answer-key pdfs, revision notebooks, screenshot/pdf answer evaluation, or deciding which upsc skill should handle a task. this skill sets defaults, date windows, output structure, marking rules, and delegates to the most specific upsc skill.
---

# UPSC Study Orchestrator

Use this skill as the routing layer before any broad UPSC study or revision task.

Load `references/upsc-core-rules.md` for date windows, source discipline, default bundle counts, marking, timing, and the five-PDF output standard.

## Routing table

- Current-affairs issue list, date-range extraction, source verification, topic inventory: use **upsc-current-affairs-intake**.
- Revision notebook or workbook-style PDF: use **upsc-revision-notebook-pdf**.
- Prelims GS1 paper, CSAT paper, Mains+Interview question paper, common answer PDF: use **upsc-test-paper-pdf**.
- Scoring/evaluation from typed answers, screenshots, images, or a PDF containing screenshots: use **upsc-answer-evaluator**.
- Interactive learning, one-subtopic teaching, doubt lock, one-MCQ-at-a-time flow: use **upsc-guided-tutor**.

## Default full bundle

When the user asks for a weekly/monthly/yearly revision bundle, generate or coordinate these separate outputs:

1. `UPSC_Prelims_GS1_Question_Paper_<date-range>.pdf`
2. `UPSC_Prelims_CSAT_Question_Paper_<date-range>.pdf`
3. `UPSC_Mains_Interview_Question_Paper_<date-range>.pdf`
4. `UPSC_Answer_Key_Explanations_<date-range>.pdf`
5. `UPSC_Revision_Notebook_<date-range>.pdf`

Default weekly counts: 50 GS1 MCQs, 20 CSAT MCQs, 10 Mains questions, 8 Interview questions. Use the user's requested counts when provided.

## Date handling

For Saturday weekly runs, use the current Sunday-to-Saturday week unless the user explicitly asks for last week/latest completed week. For monthly, multi-month, or yearly bundles, use the exact user-provided range; if unclear, ask one concise clarification.

## Bundling workflow

1. Determine date range and source inputs.
2. If uploaded PDFs/notes exist, treat them as the primary source base.
3. If the user asks for fresh date-range current affairs, verify from reliable sources before generating questions.
4. Build a topic inventory grouped by UPSC theme.
5. Generate the revision notebook PDF first when the user asks for a full bundle.
6. Generate the three question-paper PDFs separately.
7. Generate one answer/explanation PDF covering GS1, CSAT, Mains frameworks, and Interview guidance.
8. After the user attempts, route evaluation to the answer evaluator.

## Minimal response before work

If the scope is clear, proceed without asking multiple questions. If no source, topic, date range, or study material is provided, ask exactly one question requesting at least one of those inputs.
