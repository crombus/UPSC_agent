#!/usr/bin/env python3
"""Evaluate UPSC Prelims GS1 and CSAT MCQ attempts.

Expected answer key JSON:
{
  "questions": [
    {"question_id": "GS1-1", "paper": "GS1", "answer": "A", "topic": "Polity"},
    {"question_id": "CSAT-1", "paper": "CSAT", "answer": "C", "topic": "Reasoning"}
  ]
}

Expected attempts JSON:
{
  "answers": {
    "GS1-1": "A",
    "CSAT-1": "skip"
  }
}
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

SCORING = {
    "GS1": {"correct": 2.0, "incorrect": -0.33, "skip": 0.0},
    "CSAT": {"correct": 2.5, "incorrect": -0.83, "skip": 0.0},
}

SKIP_VALUES = {"", "-", "skip", "skipped", "blank", "na", "n/a", "not attempted", "unattempted"}
UNCLEAR_VALUES = {"unclear", "unknown", "illegible", "cannot read", "ambiguous"}


def norm_paper(value: Any) -> str:
    text = str(value or "GS1").strip().upper().replace(" ", "")
    if text in {"GS", "GSI", "GS-I", "PRELIMSGS", "PRELIMSGS1"}:
        return "GS1"
    if text in {"PAPERII", "PAPER-II", "CSAT", "GS2", "GS-II"}:
        return "CSAT"
    return text


def norm_answer(value: Any) -> str:
    text = str(value or "").strip().upper().replace("OPTION", "").strip()
    if text.lower() in SKIP_VALUES:
        return "SKIP"
    if text.lower() in UNCLEAR_VALUES:
        return "UNCLEAR"
    if text in {"A", "B", "C", "D"}:
        return text
    return text


def load_json(path: str) -> Dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def evaluate(answer_key: Dict[str, Any], attempts: Dict[str, Any]) -> Dict[str, Any]:
    questions: List[Dict[str, Any]] = answer_key.get("questions", [])
    answers: Dict[str, Any] = attempts.get("answers", attempts)
    summary: Dict[str, Dict[str, Any]] = {}
    rows: List[Dict[str, Any]] = []

    for q in questions:
        qid = str(q.get("question_id") or q.get("id") or q.get("number"))
        paper = norm_paper(q.get("paper", "GS1"))
        correct = norm_answer(q.get("answer"))
        user_ans = norm_answer(answers.get(qid, ""))

        if paper not in summary:
            summary[paper] = {
                "total": 0,
                "attempted": 0,
                "correct": 0,
                "incorrect": 0,
                "skipped": 0,
                "unclear": 0,
                "score": 0.0,
                "topics": {},
            }
        s = summary[paper]
        s["total"] += 1

        if user_ans == "UNCLEAR":
            result = "unclear"
            marks = 0.0
            s["unclear"] += 1
        elif user_ans == "SKIP":
            result = "skipped"
            marks = 0.0
            s["skipped"] += 1
        elif user_ans == correct:
            result = "correct"
            marks = SCORING.get(paper, SCORING["GS1"])["correct"]
            s["attempted"] += 1
            s["correct"] += 1
        else:
            result = "incorrect"
            marks = SCORING.get(paper, SCORING["GS1"])["incorrect"]
            s["attempted"] += 1
            s["incorrect"] += 1

        s["score"] += marks
        topic = str(q.get("topic") or "Unmapped")
        topic_stats = s["topics"].setdefault(topic, {"total": 0, "correct": 0, "incorrect": 0, "skipped": 0, "unclear": 0})
        topic_stats["total"] += 1
        topic_stats[result] = topic_stats.get(result, 0) + 1

        rows.append({
            "question_id": qid,
            "paper": paper,
            "topic": topic,
            "correct_answer": correct,
            "user_answer": user_ans,
            "result": result,
            "marks": round(marks, 2),
        })

    for s in summary.values():
        s["score"] = round(s["score"], 2)
        s["accuracy_among_attempted"] = round((s["correct"] / s["attempted"] * 100), 2) if s["attempted"] else 0.0

    return {"summary": summary, "rows": rows}


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate UPSC GS1/CSAT MCQ attempts")
    parser.add_argument("--answer-key", required=True, help="Path to answer key JSON")
    parser.add_argument("--attempts", required=True, help="Path to attempts JSON")
    parser.add_argument("--output", help="Optional output JSON path")
    args = parser.parse_args()

    result = evaluate(load_json(args.answer_key), load_json(args.attempts))
    if args.output:
        Path(args.output).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
