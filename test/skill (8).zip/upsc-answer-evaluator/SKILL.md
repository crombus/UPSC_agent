---
name: upsc-answer-evaluator
description: evaluate upsc attempts from typed answers, screenshots, photos of handwritten answer sheets, marked question papers, or pdfs containing screenshots. use when the user shares mcq attempts for prelims gs1 or csat, asks for score using upsc marking, uploads handwritten mains answers, interview notes, answer grids, circled/ticked options, or wants topic-wise performance, mistake classification, weak areas, and upsc readiness scoring.
---

# UPSC Answer Evaluator

Load `references/upsc-core-rules.md`, `references/evaluation-rubrics.md`, and `references/screenshot-pdf-evaluation.md` when evaluating answers.

Use `scripts/evaluate_mcq_answers.py` when a structured answer key and extracted answer list are available.

## MCQ scoring rules

GS1:

- Correct: +2.00.
- Incorrect: -0.33.
- Unattempted/skipped/blank: 0.

CSAT:

- Correct: +2.50.
- Incorrect: -0.83.
- Unattempted/skipped/blank: 0.

Do not apply negative marking to unclear answers unless the user confirms the option. Treat unclear as `Unclear`, not as wrong.

## Evaluation workflow

1. Identify answer source: typed text, screenshots/photos, marked PDF, PDF containing screenshots, or handwritten Mains/Interview pages.
2. Extract attempted answers visually when screenshots or scanned PDFs are uploaded.
3. If an answer is unclear, mark it `Unclear` instead of guessing.
4. Ask for confirmation only for unclear entries that affect scoring.
5. Compare attempts with the active answer key or uploaded Answer PDF.
6. Score GS1 and CSAT separately using their marking rules.
7. Provide combined diagnosis only after separate section scores.
8. Classify mistakes.
9. Give topic-wise performance, weak areas, and revision prescription.

## Output for Prelims evaluation

Use:

```text
## Score Summary
GS1:
- Total questions:
- Attempted:
- Correct:
- Incorrect:
- Skipped:
- Unclear:
- Raw score:
- Accuracy among attempted:
- Suggested readiness:

CSAT:
- Total questions:
- Attempted:
- Correct:
- Incorrect:
- Skipped:
- Unclear:
- Raw score:
- Accuracy among attempted:
- Qualifying-risk note:

## Topic-wise Performance

## Mistake Classification

## Strong Areas

## Weak Areas

## Must-Revise List

## UPSC Readiness Score
```

Clarify that readiness score is inference-based, not official.

## Mains and Interview evaluation

For handwritten Mains or Interview responses, evaluate only legible content. Mention unreadable parts. Do not invent missing text. Score Mains answers out of 10 using UPSC-style criteria: demand understanding, structure, content, facts, examples, keywords, intro/body/conclusion, and language. For interview responses, assess balance, maturity, factual accuracy, administrative judgement, ethics, and 90-second articulation.
