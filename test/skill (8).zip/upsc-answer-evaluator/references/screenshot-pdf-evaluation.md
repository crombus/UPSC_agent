# Screenshot and PDF Answer Evaluation

Use this when the user uploads screenshots, photos, marked PDFs, or a PDF containing screenshots of handwritten answers.

## Visual extraction rules

- Read the page visually.
- Accept answer formats: `Q1-A`, `1. A`, `1) A`, answer grids, circled options, ticks, crossed selected options, handwritten lists, and marked question papers.
- If the answer is not clear, write `Unclear`.
- Never guess unclear handwriting or faint marks.
- If both two options appear selected, mark `Unclear` unless one is clearly crossed out.
- If a question is blank, mark `Skip`.
- Preserve paper label: GS1 or CSAT.
- Preserve question numbers exactly.

## PDF containing screenshots

If the uploaded file is a PDF of screenshots or scanned answer sheets:

1. Inspect each page visually.
2. Extract answers page by page.
3. Build a clean table: Paper, Question No., Extracted answer, Confidence, Notes.
4. Ask for confirmation only for unclear entries.
5. After confirmation or if no unclear entries exist, score the attempt.

## Mains handwriting

- Evaluate only readable content.
- Mention unreadable lines or paragraphs.
- Do not infer missing arguments from context.
- Evaluate answer structure, relevance, factual accuracy, examples, language, and conclusion.

## Interview handwritten notes

- Treat them as bullet-point raw material.
- Evaluate balance, clarity, maturity, ethics, factual correctness, and 90-second articulation.
