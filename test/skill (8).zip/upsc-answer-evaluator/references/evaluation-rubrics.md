# Evaluation Rubrics

## Mistake classification
Classify each wrong MCQ as one or more of:

- Factual error.
- Conceptual error.
- Static linkage gap.
- Current affairs confusion.
- Elimination error.
- Overthinking.
- Misread statement.
- Confused institution/ministry.
- Confused report/index.
- Confused treaty/convention.
- Timeline/date confusion.
- Calculation error for CSAT.
- Comprehension inference error for CSAT.
- Time-management error.

## Readiness scoring
Use an inference-based score out of 100.

- 85-100: highly ready for this content set.
- 70-84: good, revise traps.
- 50-69: moderate, revise concepts and facts.
- 30-49: weak, repeat major topics.
- 0-29: not ready, restart revision.

Always say this is not an official UPSC score.

## Mains answer score out of 10
Assess:

- Demand understanding.
- Structure.
- Content richness.
- Factual accuracy.
- Static-current affairs linkage.
- Examples/data/judgments where relevant.
- Keywords.
- Balanced conclusion.
- Language clarity.
- Time suitability.

## Interview response assessment
Assess:

- Balance and maturity.
- Factual correctness.
- Constitutional/ethical grounding.
- Administrative practicality.
- Brevity.
- Ability to handle follow-ups.
- Avoidance of extreme or ideological framing.
