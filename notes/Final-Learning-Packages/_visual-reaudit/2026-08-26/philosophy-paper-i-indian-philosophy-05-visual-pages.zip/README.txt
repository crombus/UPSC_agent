Topic: philosophy-paper-i-indian-philosophy-05
Each listed source visual was mapped to the exact PDF page(s). JPEGs are 97.2 dpi raster previews used for page-by-page readability review.
